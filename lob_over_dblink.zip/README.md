-- *************************** --

#  LOB_OVER_DBLINK

A PL/SQL package for selecting CLOBs and BLOBs across a DBLink.

It contains two small functions:
GET_CLOB(....): Selects a CLOB over a DBLink.
GET_BLOB(....): Selects a BLOB over a DBLink.

*LOB_OVER_DBLINK* requires **NO SETUP** on the remote database.

-- *************************** --

## Example usage:

select id, lob_over_dblink.get_clob('some_dblink', 'some_table', 'some_clob_column', rowid)
  from some_table@some_dblink;

-- *************************** --

## Installing and uninstalling:

Download and extract the zip file.
Using SQL*Plus:
  - To Install:   SQL>@install
  - To uninstall: SQL>@uninstall

-- *************************** --

## Author:

Laurence Prescott
howdprescott@hotmail.com
https://github.com/LaurencePrescott/github-link

-- *************************** --
:smiling_imp:
[![Donate](https://www.paypalobjects.com/en_AU/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=98KZQ5FSKWRTC&lc=AU&item_name=LobOverDBLink&item_number=LODB_1&currency_code=AUD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted)

-- *************************** --
