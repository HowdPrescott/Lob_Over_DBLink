prompt
prompt
prompt . ******************************* .
prompt .    Lob.Over.DBLink installer    .
prompt .    Laurence Prescott            .
prompt . ******************************* .
prompt

prompt Install package specification...
@@lob_over_dblink.pks
prompt Install package body...
@@lob_over_dblink.pkb

prompt
prompt . ******************************* .
prompt .    Install complete             .
prompt . ******************************* .
prompt
