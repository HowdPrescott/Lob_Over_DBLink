prompt
prompt
prompt . ********************************* .
prompt .    Lob.Over.DBLink uninstaller    .
prompt .    Laurence Prescott              .
prompt . ********************************* .
prompt

prompt Drop package
drop package lob_over_dblink;

prompt
prompt . ********************************* .
prompt .    Uninstall complete             .
prompt . ********************************* .
prompt
